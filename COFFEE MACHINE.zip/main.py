end_of_transaction = True
Money = 0


def main(name_of_coffee):

  global Money
  

  print("Please insert coins.")
  quarters = int(input("How many quarters?💵 "))
  dimes = int(input("How many dimes?💵 "))
  nickels = int(input("How many nickles?💵 "))
  pennies = int(input("How many pennies?💵 "))

  tq = quarters*0.25
  td = dimes*0.10
  tp = pennies*0.01
  tn = nickels*0.05

  total_user = tq+td+tp+tn

  change_e = total_user - MENU[name_of_coffee]["cost"]

    
  if total_user >= MENU[name_of_coffee]["cost"]:

    Money += MENU[name_of_coffee]["cost"]

    return f"Here is ${change_e} in change.\nHere is your espresso ☕️. Enjoy!\n"


  else:
    return"Sorry that's not enough money. Money refunded 💵.\n "




  












MENU = {
    "espresso": {
        "ingredients": {
            "water": 50,
            "coffee": 18,
        },
        "cost": 1.5,
    },
    "latte": {
        "ingredients": {
            "water": 200,
            "milk": 150,
            "coffee": 24,
        },
        "cost": 2.5,
    },
    "cappuccino": {
        "ingredients": {
            "water": 250,
            "milk": 100,
            "coffee": 24,
        },
        "cost": 3.0,
    }
}

resources = {
    "water": 300,
    "milk": 200,
    "coffee": 100,
}

leftover_water = 300 
leftover_milk = 200
leftover_coffee = 100






print("***PRICE of espresso ☕️ - $1.5\nPRICE of latte ☕️ - $2.5\nPRICE of cappuccino ☕️ - $3.0\n\n")

print("Type 'report' 📝 to see the amount of,\nWater 💧 ,\nMilk 🐄,\nCoffee ☕️,\nMoney paid by you to the coffee machine\n\n")

print("Type 'off' ​📴​ to switch off the coffee machine***\n\n\n\n\n")





while end_of_transaction:
  
  

  ask_user_what_they_need = input("What would you like? (espresso ☕️/latte ☕️/cappuccino ☕️? \n")

  
  report_water = resources["water"]
  report_milk = resources["milk"]
  report_coffee = resources["coffee"]


  if ask_user_what_they_need == "Report".lower():


    print(f"Water 💧: {leftover_water}ml\nMilk 🐄: {leftover_milk}ml\nCoffee ☕️: {leftover_coffee}g\nMoney 💵: ${Money}\n")




  elif ask_user_what_they_need == "espresso":

    if leftover_water >= 50 and leftover_coffee >= 18:

      for_espresso = main(name_of_coffee = ask_user_what_they_need )

      print(for_espresso)


      leftover_water = leftover_water - MENU["espresso"]["ingredients"]["water"]
      leftover_coffee = leftover_coffee - MENU["espresso"]["ingredients"]["coffee"]

      
     

    elif not leftover_water >= 50 or not leftover_coffee >= 18:

      if not leftover_water >= 50 and not leftover_coffee >= 18: 
        print("Sorry there is not enough water 💧 and coffee ☕️.\n") 

      elif not leftover_water >= 50:
        print("Sorry there is not enough water 💧.\n")

      elif not leftover_coffee >= 18:
        print("Sorry there is not enough coffee ☕️.\n")

     



          
      



  elif ask_user_what_they_need == "latte":

    if leftover_water >= 200 and leftover_coffee >= 24 and leftover_milk >= 150:

      for_latte = main(name_of_coffee = ask_user_what_they_need )

      print(for_latte)

      
      leftover_water = leftover_water - MENU["latte"]["ingredients"]["water"]
      leftover_coffee = leftover_coffee - MENU["latte"]["ingredients"]["coffee"]
      leftover_milk = leftover_milk - MENU["latte"]["ingredients"]["milk"]

      


    elif not leftover_water >= 200 or not leftover_coffee >= 24 or leftover_milk >= 150:

      if not leftover_water >= 200 and not leftover_coffee >= 24 and leftover_milk >= 150:
         print("Sorry there is not enough water 💧, milk 🐄 and coffee ☕️.\n")

      elif not leftover_water >= 200 and not leftover_milk >= 150: 
        print("Sorry there is not enough water 💧 and milk 🐄.\n") 

      elif not leftover_water >= 200 and not leftover_coffee >= 24: 
        print("Sorry there is not enough water 💧 and coffee ☕️.\n") 

      elif not leftover_coffee >= 24 and not leftover_milk >= 150: 
        print("Sorry there is not enough coffee ☕️ and milk 🐄.\n")     

      elif not leftover_water >= 200:
        print("Sorry there is not enough water 💧.\n")

      elif not leftover_coffee >= 24:
        print("Sorry there is not enough coffee ☕️.\n")

      elif not leftover_milk >= 150:
        print("Sorry there is not enough milk 🐄.\n")  



          

        



  elif ask_user_what_they_need == "cappuccino":
    if leftover_water >= 250 and leftover_coffee >= 24 and leftover_milk >= 100 :

      for_cappuccino = main(name_of_coffee = ask_user_what_they_need )

      print(for_cappuccino)

      
      
      

      leftover_water = leftover_water - MENU["cappuccino"]["ingredients"]["water"]
      leftover_coffee = leftover_coffee - MENU["cappuccino"]["ingredients"]["coffee"]
      leftover_milk = leftover_milk - MENU["cappuccino"]["ingredients"]["milk"] 

      

      
      
              

    elif not leftover_water >= 250 or not leftover_coffee >= 24 or leftover_milk >= 100:

      if not leftover_water >= 250 and not leftover_coffee >= 24 and leftover_milk >= 100:
        print("Sorry there is not enough water 💧, milk 🐄 and coffee ☕️.\n")

      elif not leftover_water >= 250 and not leftover_milk >= 100: 
        print("Sorry there is not enough water 💧 and milk 🐄.\n") 

      elif not leftover_water >= 250 and not leftover_coffee >= 24: 
        print("Sorry there is not enough water 💧 and coffee ☕️.\n") 

      elif not leftover_coffee >= 24 and not leftover_milk >= 100: 
        print("Sorry there is not enough milk 🐄 and coffee ☕️.\n")     

      elif not leftover_water >= 250:
        print("Sorry there is not enough water 💧.\n")

      elif not leftover_coffee >= 24:
        print("Sorry there is not enough coffee ☕️.\n")

      elif not leftover_milk >= 100:
        print("Sorry there is not enough milk 🐄.\n")  

  elif ask_user_what_they_need == 'off':
    end_of_transaction = False